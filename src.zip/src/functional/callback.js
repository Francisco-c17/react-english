import React from "react";

const Callback = (props) => (
  <div>
    Callback
    {console.log("props", props)}
  </div>
);

export default Callback;
