
export const SUCCESS = 'SUCCESS'
export const FAILURE = 'FAILURE' 
export const USER_INPUT = 'USER_INPUT'