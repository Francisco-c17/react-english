import { createBrowserHistory } from "history";

export default createBrowserHistory();
//npm install --save history
