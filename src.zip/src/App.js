import React from "react";
import "./App.css";
import Container1 from "./containers/container1";
import Routes from "./routes";
function App() {
  return (
    <div className="App">
      React Francisco
      <Routes />
    </div>
  );
}

export default App;
