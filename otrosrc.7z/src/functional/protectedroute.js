import React from "react";

const ProtectedRoute = props => <div>ProtectedRoute</div>;

export default ProtectedRoute;
