import React from "react";

const Component1 = (props) => (
  <div>
    Component {props.match.params.id}
    {console.log("Props", props)}
  </div>
);

/*Component1.defaultProps = {
  name:"Jose"
}*/
export default Component1;
