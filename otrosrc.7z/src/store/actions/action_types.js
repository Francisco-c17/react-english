export const SUCCESS = "SUCCESS";
export const FAILURE = "FAILURE";
export const USER_INPUT = "USER_INPUT";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAILURE = "LOGIN_FAILURE";
